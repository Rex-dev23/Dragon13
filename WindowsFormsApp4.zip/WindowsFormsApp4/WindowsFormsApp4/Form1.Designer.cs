﻿namespace WindowsFormsApp4
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.numericUpDownDragon2Heal = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownDragon1Heal = new System.Windows.Forms.NumericUpDown();
            this.labelDragon2HP = new System.Windows.Forms.Label();
            this.labelDragon1HP = new System.Windows.Forms.Label();
            this.buttonAverageHitPower = new System.Windows.Forms.Button();
            this.buttonHealDragon2 = new System.Windows.Forms.Button();
            this.buttonHealDragon1 = new System.Windows.Forms.Button();
            this.buttonAttackDragon2 = new System.Windows.Forms.Button();
            this.buttonAttackDragon1 = new System.Windows.Forms.Button();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.textBoxHealAmountDragon2 = new System.Windows.Forms.TextBox();
            this.textBoxHealAmountDragon1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDragon2Heal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDragon1Heal)).BeginInit();
            this.SuspendLayout();
            // 
            // numericUpDownDragon2Heal
            // 
            this.numericUpDownDragon2Heal.Location = new System.Drawing.Point(544, 102);
            this.numericUpDownDragon2Heal.Name = "numericUpDownDragon2Heal";
            this.numericUpDownDragon2Heal.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownDragon2Heal.TabIndex = 25;
            // 
            // numericUpDownDragon1Heal
            // 
            this.numericUpDownDragon1Heal.Location = new System.Drawing.Point(137, 92);
            this.numericUpDownDragon1Heal.Name = "numericUpDownDragon1Heal";
            this.numericUpDownDragon1Heal.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownDragon1Heal.TabIndex = 24;
            // 
            // labelDragon2HP
            // 
            this.labelDragon2HP.AutoSize = true;
            this.labelDragon2HP.Location = new System.Drawing.Point(588, 277);
            this.labelDragon2HP.Name = "labelDragon2HP";
            this.labelDragon2HP.Size = new System.Drawing.Size(35, 13);
            this.labelDragon2HP.TabIndex = 23;
            this.labelDragon2HP.Text = "label1";
            // 
            // labelDragon1HP
            // 
            this.labelDragon1HP.AutoSize = true;
            this.labelDragon1HP.Location = new System.Drawing.Point(172, 277);
            this.labelDragon1HP.Name = "labelDragon1HP";
            this.labelDragon1HP.Size = new System.Drawing.Size(35, 13);
            this.labelDragon1HP.TabIndex = 22;
            this.labelDragon1HP.Text = "label1";
            // 
            // buttonAverageHitPower
            // 
            this.buttonAverageHitPower.Location = new System.Drawing.Point(403, 102);
            this.buttonAverageHitPower.Name = "buttonAverageHitPower";
            this.buttonAverageHitPower.Size = new System.Drawing.Size(75, 23);
            this.buttonAverageHitPower.TabIndex = 21;
            this.buttonAverageHitPower.Text = "button1";
            this.buttonAverageHitPower.UseVisualStyleBackColor = true;
            // 
            // buttonHealDragon2
            // 
            this.buttonHealDragon2.Location = new System.Drawing.Point(564, 234);
            this.buttonHealDragon2.Name = "buttonHealDragon2";
            this.buttonHealDragon2.Size = new System.Drawing.Size(75, 23);
            this.buttonHealDragon2.TabIndex = 20;
            this.buttonHealDragon2.Text = "button4";
            this.buttonHealDragon2.UseVisualStyleBackColor = true;
            // 
            // buttonHealDragon1
            // 
            this.buttonHealDragon1.Location = new System.Drawing.Point(153, 234);
            this.buttonHealDragon1.Name = "buttonHealDragon1";
            this.buttonHealDragon1.Size = new System.Drawing.Size(75, 23);
            this.buttonHealDragon1.TabIndex = 19;
            this.buttonHealDragon1.Text = "button3";
            this.buttonHealDragon1.UseVisualStyleBackColor = true;
            // 
            // buttonAttackDragon2
            // 
            this.buttonAttackDragon2.Location = new System.Drawing.Point(564, 176);
            this.buttonAttackDragon2.Name = "buttonAttackDragon2";
            this.buttonAttackDragon2.Size = new System.Drawing.Size(75, 23);
            this.buttonAttackDragon2.TabIndex = 18;
            this.buttonAttackDragon2.Text = "button2";
            this.buttonAttackDragon2.UseVisualStyleBackColor = true;
            // 
            // buttonAttackDragon1
            // 
            this.buttonAttackDragon1.Location = new System.Drawing.Point(153, 176);
            this.buttonAttackDragon1.Name = "buttonAttackDragon1";
            this.buttonAttackDragon1.Size = new System.Drawing.Size(75, 23);
            this.buttonAttackDragon1.TabIndex = 17;
            this.buttonAttackDragon1.Text = "button1";
            this.buttonAttackDragon1.UseVisualStyleBackColor = true;
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(564, 335);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(100, 23);
            this.progressBar2.TabIndex = 16;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(137, 335);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(100, 23);
            this.progressBar1.TabIndex = 15;
            // 
            // textBoxHealAmountDragon2
            // 
            this.textBoxHealAmountDragon2.Location = new System.Drawing.Point(564, 293);
            this.textBoxHealAmountDragon2.Name = "textBoxHealAmountDragon2";
            this.textBoxHealAmountDragon2.Size = new System.Drawing.Size(100, 20);
            this.textBoxHealAmountDragon2.TabIndex = 14;
            // 
            // textBoxHealAmountDragon1
            // 
            this.textBoxHealAmountDragon1.Location = new System.Drawing.Point(137, 293);
            this.textBoxHealAmountDragon1.Name = "textBoxHealAmountDragon1";
            this.textBoxHealAmountDragon1.Size = new System.Drawing.Size(100, 20);
            this.textBoxHealAmountDragon1.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.numericUpDownDragon2Heal);
            this.Controls.Add(this.numericUpDownDragon1Heal);
            this.Controls.Add(this.labelDragon2HP);
            this.Controls.Add(this.labelDragon1HP);
            this.Controls.Add(this.buttonAverageHitPower);
            this.Controls.Add(this.buttonHealDragon2);
            this.Controls.Add(this.buttonHealDragon1);
            this.Controls.Add(this.buttonAttackDragon2);
            this.Controls.Add(this.buttonAttackDragon1);
            this.Controls.Add(this.progressBar2);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.textBoxHealAmountDragon2);
            this.Controls.Add(this.textBoxHealAmountDragon1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDragon2Heal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDragon1Heal)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numericUpDownDragon2Heal;
        private System.Windows.Forms.NumericUpDown numericUpDownDragon1Heal;
        private System.Windows.Forms.Label labelDragon2HP;
        private System.Windows.Forms.Label labelDragon1HP;
        private System.Windows.Forms.Button buttonAverageHitPower;
        private System.Windows.Forms.Button buttonHealDragon2;
        private System.Windows.Forms.Button buttonHealDragon1;
        private System.Windows.Forms.Button buttonAttackDragon2;
        private System.Windows.Forms.Button buttonAttackDragon1;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.TextBox textBoxHealAmountDragon2;
        private System.Windows.Forms.TextBox textBoxHealAmountDragon1;
    }
}

