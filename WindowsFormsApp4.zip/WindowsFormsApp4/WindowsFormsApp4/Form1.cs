﻿using System;
using System.Windows.Forms;
using System.Diagnostics;
using Dragon1;


namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        private Dragon dragon1;
        private Dragon dragon2;
        private bool dragon1CanAttack = true;
        private bool dragon2CanAttack = true;
        private int dragon1AttackPower;
        private int dragon2AttackPower;
        private int dragon1TotalAttackPower;
        private int dragon2TotalAttackPower;
        private int dragon1AttackCount;
        private int dragon2AttackCount;

        public Form1()
        {
            InitializeComponent();
            dragon1 = new Dragon(100, 100, 8, 15);
            dragon2 = new Dragon(100, 100, 4, 10);
            progressBar1.Maximum = dragon1.MaxHP;
            progressBar2.Maximum = dragon2.MaxHP;
            UpdateHealthBars();
        }

        private void buttonDragon1Attack_Click(object sender, EventArgs e)
        {
            if (dragon1CanAttack)
            {
                dragon1AttackPower = dragon1.Attack();
                dragon2.TakeDamage(dragon1AttackPower);
                dragon1TotalAttackPower += dragon1AttackPower;
                dragon1AttackCount++;
                dragon1CanAttack = false;
                dragon2CanAttack = true;
                UpdateHealthBars();
                Debug.WriteLine("Dragon 1 attacked with power " + dragon1AttackPower);

            }

        }

        private void buttonDragon2Attack_Click(object sender, EventArgs e)
        {
            if (dragon2CanAttack)
            {
                dragon2AttackPower = dragon2.Attack();
                dragon1.TakeDamage(dragon2AttackPower);
                dragon2TotalAttackPower += dragon2AttackPower;
                dragon2AttackCount++;
                dragon2CanAttack = false;
                dragon1CanAttack = true;
                UpdateHealthBars();
                Debug.WriteLine("Dragon 2 attacked with power " + dragon2AttackPower);
            }
        }



        private void buttonDragon1Heal_Click(object sender, EventArgs e)
        {
            int amount = (int)numericUpDownDragon1Heal.Value;
            dragon1.Heal(amount);
            UpdateHealthBars();
        }

        private void buttonDragon2Heal_Click(object sender, EventArgs e)
        {
            int amount = (int)numericUpDownDragon2Heal.Value;
            dragon2.Heal(amount);
            UpdateHealthBars();
        }



        private void buttonAverageAttackPower_Click(object sender, EventArgs e)
        {
            double dragon1AverageAttackPower = (double)dragon1TotalAttackPower / dragon1AttackCount;
            double dragon2AverageAttackPower = (double)dragon2TotalAttackPower / dragon2AttackCount;
            MessageBox.Show($"Dragon 1 average attack power: {dragon1AverageAttackPower}\nDragon 2 average attack power: {dragon2AverageAttackPower}");
            dragon1TotalAttackPower = 0;
            dragon2TotalAttackPower = 0;
            dragon1AttackCount = 0;
            dragon2AttackCount = 0;
        }

        private void UpdateHealthBars()
        {
            progressBar1.Value = dragon1.CurrentHP;
            progressBar2.Value = dragon2.CurrentHP;
            labelDragon1HP.Text = $"HP: {dragon1.CurrentHP}/{dragon1.MaxHP}";
            labelDragon2HP.Text = $"HP: {dragon2.CurrentHP}/{dragon2.MaxHP}";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }

}
