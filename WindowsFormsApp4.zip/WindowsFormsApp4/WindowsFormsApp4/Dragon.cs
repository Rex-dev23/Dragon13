﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dragon1
{
    public class Dragon
    {
        public int MaxHP { get; set; }
        public int CurrentHP { get; set; }
        public int MaxAttackLevel { get; set; }
        public int MinAttackLevel { get; set; }

        public Dragon(int maxHP, int currentHP, int maxAttackLevel, int minAttackLevel)
        {
            MaxHP = maxHP;
            CurrentHP = currentHP;
            MaxAttackLevel = maxAttackLevel;
            MinAttackLevel = minAttackLevel;
        }

        public int Attack()
        {
            Random random = new Random();
            int attackPower = random.Next(MinAttackLevel, MaxAttackLevel + 1);
            return attackPower;
        }

        public void TakeDamage(int damage)
        {
            CurrentHP -= damage;
            if (CurrentHP < 0)
            {
                CurrentHP = 0;
            }
        }

        public void Heal(int amount)
        {
            CurrentHP += amount;
            if (CurrentHP > MaxHP)
            {
                CurrentHP = MaxHP;
            }
        }
    }

}
